import { combineReducers } from "redux";
import { customers } from './customers';

export default combineReducers({
  customers
});