export const urlCustomers = 'http://localhost:3001/customers';
