## Segunda aplicación de ejemplo

Focalizado en utilización de conceptos integradores de todo lo visto en la primer parte del curso

Primero, antes de ejecutar "npm start", se debe levantar el servidor json-server

json-server --watch db.json --port 3001